﻿namespace Application
{
    public static class AssemblyReference { }
}
